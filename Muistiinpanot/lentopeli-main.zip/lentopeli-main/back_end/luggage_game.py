import random

def add_luggage(connection):
    from database import get_items

    items = get_items(connection)
    weights = [max(1, 6 - item["danger_level"]) for item in items]

    chosen = []
    available_items = items[:]
    available_weights = weights[:]

    for _ in range(min(5, len(available_items))):
        total = sum(available_weights)
        r = random.uniform(0, total)
        upto = 0
        for i, w in enumerate(available_weights):
            upto += w
            if r <= upto:
                chosen_item = available_items.pop(i)
                available_weights.pop(i)
                chosen.append(chosen_item)
                break
    return chosen

#tarkistaa onko matkattavaroissa sallittuja tavaroita
def is_safe_luggage(bag):
    for item in bag:
        if item["security_class"]==1:
            return False
    return True