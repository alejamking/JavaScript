from geopy.distance import geodesic
def fly_menu(player, conn, route, current_index, airport_choices):
    # Check if the player is already at the final destination
    if current_index >= len(route) - 1:
        print("\nYou are already at your final destination Australia!")
        return player["location"], current_index

    # Get the next country in the travel route
    next_country = route[current_index + 1]
    # Get the pre-saved airports for that country
    next_airports = airport_choices.get(next_country, [])

    # If no airports found, skip this country
    if not next_airports:
        print(f"\nNo valid airports found in {next_country}. Skipping this destination.")
        return player["location"], current_index + 1

    # Print the available airport options in the next country
    print(f"\nNext destination options in {next_country}: ")
    for i, airport in enumerate(next_airports, 1):
        distance, price = calculate_distance_and_price(player["location"], airport)
        print(f"{i}, {airport[0]} ({airport[1]}) - {distance} km, Price: {price} €")

    # Ask the player to choose an airport
    choice = input("Choose your next airport (1 or 2): ")
    if choice not in ["1", "2"]:
        print("Invalid choice, staying at current airport.")
        return player["location"], current_index

    # Select the chosen airport
    next_airport = next_airports[int(choice) - 1]
    distance, price = calculate_distance_and_price(player["location"], next_airport)

    # Check if player has enough money to fly
    if player["balance"] >= price:
        player["balance"] -= price
        player["location"] = next_airport
        player["day"] += 1
        current_index += 1
        balance = float(player['balance'])
        print(f"\nYou flew to: {next_airport[0]}, {next_airport[1]}")
        print(f"Flight cost: {price} €. Remaining balance: {balance:.2f} €")
        # Check if this is the final destination
        if current_index == len(route) - 1:
            balance = float(player['balance'])
            print("\nCongratulations! You have reached your final destination: Australia!")
            print(f"Days traveled: {player['day']}")
            print(f"Final balance: {balance:.2f} €")
            news.print_news_by_country("Australia")
            quit()
        # Return the new location and updated index
        return next_airport, current_index
    else:
        # Not enough money to fly
        print("\nNot enough money for this flight!")
        return player["location"], current_index


def calculate_distance_and_price(current_airport, next_airport, price_per_km=0.06):
    # Convert latitude/longitude to floats
    current_coords = (float(current_airport[2]), float(current_airport[3]))
    next_coords = (float(next_airport[2]), float(next_airport[3]))

    distance = geodesic(current_coords, next_coords).km
    price = round(distance * price_per_km, 2)
    return round(distance, 1), price