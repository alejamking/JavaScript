from flask import Flask, request, jsonify, session
from flask_cors import CORS
from database import get_db, get_starting_airport, get_two_airports
from luggage_game import add_luggage, is_safe_luggage
from routes_config import ROUTES
from geopy.distance import geodesic
app = Flask(__name__)
CORS(app, 
    supports_credentials=True,
    origins=['http://localhost:8005', 'http://127.0.0.1:8005', '*'],
    allow_headers=['Content-Type'],
    methods=['GET', 'POST', 'OPTIONS'])

#säilyttää pelaajan tiedot
SESSION = {
    "player": None,
    "balance": 50,
    "day": 1,
    "penalties": 0,
    "location": None
}

@app.route('/api/start-game', methods=['POST'])
def start_game():
    """aloittaa pelin ja hakee satunnaisen lentokentän"""
    data = request.json
    player_name = data['playerName']
    starting_country = data['startingCountry']

    #hakee satunnaisen lentokentän teitokannasta
    conn = get_db()
    airport = get_starting_airport(conn, starting_country)
    conn.close()

    #tallenna tiedot
    SESSION["player"] = player_name
    SESSION["location"] = airport
    SESSION["balance"] = 50
    SESSION["day"] = 1
    SESSION["penalties"] = 0
    SESSION["bags_checked"] = 0
    SESSION["route"] = ROUTES[starting_country]
    SESSION["route_index"] = 0

    #palautetaan front-endille
    return jsonify({
        'playerName': player_name,
        'airportName': airport[0],
        'country': airport[1],
        'latitude': airport[2],
        'longitude': airport[3],
        'day': 1,
        'balance': 50,
        'penalties': 0,
        'route': ROUTES[starting_country]
    })

@app.route('/api/reset-game', methods=['POST', 'OPTIONS'])
def reset_game():
    """Nollaa pelin tiedot kokonaan"""
    if request.method == 'OPTIONS':
        return '', 200
    
    # Nollaa kaikki SESSION tiedot
    SESSION["player"] = None
    SESSION["balance"] = 50
    SESSION["day"] = 1
    SESSION["penalties"] = 0
    SESSION["location"] = None
    SESSION["bags_checked"] = 0
    SESSION["current_bag"] = None
    SESSION["route"] = None
    SESSION["route_index"] = 0
    
    return jsonify({"message": "Game reset successful"})


@app.route('/api/work/get-bag', methods=['GET', 'OPTIONS'])
def get_bag():
    if request.method=='OPTIONS':
        return '', 200

    if SESSION["bags_checked"] >=5:
        return jsonify({"error": "Work day finished"}), 400

    conn = get_db()
    bag = add_luggage(conn)
    conn.close()

    SESSION["current_bag"] = bag

    return jsonify({
        'bagNumber': SESSION["bags_checked"] + 1,
        'items': [
            {
                'name': item['name'],
                'description': item['description']
            }
            for item in bag
        ]
    })

@app.route('/api/work/check-decision', methods=['POST', 'OPTIONS'])
def check_bag_decision():
    if request.method == 'OPTIONS':
        return '', 200

    data = request.json
    decision = data['decision']

    bag = SESSION.get("current_bag")
    if not bag:
        return jsonify({"error": "No bag in progress"})

    game_over = False
    correct = False
    message = ""
    reasons = []

    danger_items = [item["name"] for item in bag if item["danger_level"] == 5]
    if decision == "allow" and danger_items:
        reasons.append(f"Contained danger level 5 items: {', '.join(danger_items)}")
        message = "GAME OVER: You allowed a danger level 5 item!"
        game_over = True

    suspicious_items = [item["name"] for item in bag if item["security_class"] == 1 and item["danger_level"] < 5]
    if decision == "allow" and suspicious_items and not game_over:
        reasons.append(f"Suspicious item allowed: {', '.join(suspicious_items)}")
        message = "Wrong! You let a suspicious item through!"
        SESSION["penalties"] += 1

    if decision == "deny" and is_safe_luggage(bag) and not game_over:
        reasons.append("Denied a completely safe bag")
        message = "Wrong! Why didn't you let that safe bag through?"
        SESSION["penalties"] += 1

    if not reasons and not game_over:
        correct = True
        message = "Correct!"

    if correct:
        SESSION["balance"] += 20
    else:
        SESSION["balance"] -= 10

    if SESSION["penalties"] >= 5:
        game_over = True
        message = "GAME OVER! You have received 5 penalties."

    SESSION["bags_checked"] += 1
    work_day_finished = (SESSION["bags_checked"] >= 5)

    item_details = []
    for item in bag:
        detail = f"{item['name']}"
        if item['security_class'] == 1:
            detail += f" (FORBIDDEN, danger level {item['danger_level']})"
        else:
            detail += f" (safe)"
        item_details.append(detail)

    return jsonify({
        'correct': correct,
        'gameOver': game_over,
        'message': message,
        'reasons': reasons,
        'newBalance': SESSION["balance"],
        'penalties': SESSION["penalties"],
        'bagsChecked': SESSION["bags_checked"],
        'workDayFinished': work_day_finished,
        'itemNames': item_details
    })

@app.route('/api/work/end-day', methods=['POST', 'OPTIONS'])
def end_work_day():
    if request.method == 'OPTIONS':
        return '', 200

    SESSION["day"] += 1
    SESSION["bags_checked"] = 0
    SESSION["current_bag"] = None

    return jsonify({
        'message': 'Work day completed',
        'day': SESSION["day"],
        'balance': SESSION["balance"]
    })


##LENTÄMINEN
@app.route("/api/fly-options", methods=["POST"])
def fly_options():
    data = request.json
    index = data["index"]
    route = data["route"]
    current_airport = SESSION["location"]

    next_country = route[index + 1]
    airports = get_two_airports(get_db(), next_country)

    airport_list = []
    for airport in airports:
        dist = geodesic(
            (float(current_airport[2]), float(current_airport[3])),
            (float(airport[2]), float(airport[3]))
        ).km
        price = round(dist * 0.06, 2)

        airport_list.append({
            "name": airport[0],
            "country": airport[1],
            "lat": airport[2],
            "lon": airport[3],
            "distance": round(dist, 1),
            "price": price
        })

    return jsonify({"airports": airport_list})

@app.route("/api/fly", methods=["POST"])
def fly():
    data = request.json
    choice = data.get("choice")
    route = data.get("route")
    index = data.get("index")
    airport_choices = data.get("airportChoices")

    if index >= len(route) - 1:
        return jsonify({"error": "Already at final destination"}), 400

    next_country = route[index + 1]
    airports = airport_choices.get(next_country)
    if not airports:
        return jsonify({"error": "No airports provided"}), 400

    chosen_airport = airports[choice - 1]

    #MATKAN HINTA
    current_location = SESSION["location"]
    distance = geodesic(
        (current_location[2], current_location[3]),
        (chosen_airport[2], chosen_airport[3])
    ).km
    price = round(distance * 0.06, 2)

    if SESSION["balance"] < price:
        return jsonify({
            "error": "Not enough money for this flight!",
            "player": SESSION,
            "index": index,
            "arrived": False
        })

    #SESSION PÄIVITYS
    SESSION["balance"] -= price
    SESSION["location"] = chosen_airport
    SESSION["day"] += 1
    index += 1
    SESSION["route_index"] = index

    arrived = (index == len(route) - 1)

    return jsonify({
        "player": SESSION,
        "index": index,
        "message": f"Flew to {chosen_airport[0]}, {chosen_airport[1]} costing {price}€",
        "arrived": arrived
    })





if __name__ == '__main__':
    app.run(debug=True, port=5420)