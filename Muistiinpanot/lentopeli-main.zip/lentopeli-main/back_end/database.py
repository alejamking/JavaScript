import mysql.connector
import random
# import pymysql
from geopy.distance import geodesic

def get_db(user="nimi", password="salasana"):
    """connecting database (change user and password for testing)"""
    yhteys = mysql.connector.connect(
        host = 'localhost',
        port = 3306,
        database = 'flight_game',
        user = user,
        password = password,
        autocommit = True
    )
    return yhteys

def get_starting_airport(connection, first_country):
    """randomizing starting airport from users choice"""
    sql = """
        SELECT airport.name, country.name, airport.latitude_deg, airport.longitude_deg
        FROM airport 
        JOIN country ON country.iso_country = airport.iso_country
        WHERE country.name = %s
        AND airport.type = 'medium_airport' 
        AND scheduled_service = 'yes'
    """
    cursor = connection.cursor()
    cursor.execute(sql, (first_country,))
    result = cursor.fetchall()
    return random.choice(result)

def get_two_airports(connection, next_country):
    """
    returns two random airports from given country.
    returns list: (ident, name, country, lat, lon)
    """
    sql = """
        SELECT airport.name, country.name, 
               airport.latitude_deg, airport.longitude_deg
        FROM airport
        JOIN country ON country.iso_country = airport.iso_country
        WHERE country.name = %s
          AND airport.type IN ('medium_airport','large_airport')
          AND scheduled_service = 'yes'
    """
    cursor = connection.cursor()
    cursor.execute(sql, (next_country,))
    result = cursor.fetchall()
    if len(result) < 2:
        return None
    return random.sample(result, 2)

def get_items(connection):
    sql = """
          SELECT items.id, \
                 items.name,
                 items.danger_level, \
                 items.description, \
                 items.security_class
          FROM items
    """
    cursor = connection.cursor()
    cursor.execute(sql)
    items = [
        {
            "id": row[0],
            "name": row[1],
            "danger_level": row[2],
            "description": row[3],
            "security_class": row[4]
        }
        for row in cursor.fetchall()
    ]
    return items

def calculate_distance_and_price(current_airport, next_airport, price_per_km=0.06):
    # Calculate price of flight ticket based on distance and rate per km
    distance = geodesic(
        (current_airport[2], current_airport[3]), # Current airport lat/lon
        (next_airport[2], next_airport[3])  # Next airport lat/lon
    ).km
    # Calculate price of flight ticket based on distance and rate per km
    price = round(distance * price_per_km, 2)
    # Return the rounded distance (km) and price (€)
    return round(distance, 1), price