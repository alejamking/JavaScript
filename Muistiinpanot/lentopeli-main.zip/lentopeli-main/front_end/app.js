document.addEventListener('DOMContentLoaded', function () {

    // pelaaja täyttää aloituslomakkeen ja painaa "start game"
    document.getElementById('start-form').addEventListener('submit', async function (e) {
        e.preventDefault(); // Estää sivun uudelleenlatauksen

        const playerName = document.getElementById('player-name').value;
        const startingCountry = document.getElementById('starting-country').value;

        try {
            // lähettää datan flaskille
            const response = await fetch('http://localhost:5420/api/start-game', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    playerName: playerName,
                    startingCountry: startingCountry
                })
            });

            const gameData = await response.json();

            // päivittää pelaajan tiedot näytölle
            document.getElementById('stat-name').textContent = gameData.playerName;
            document.getElementById('stat-day').textContent = gameData.day;
            document.getElementById('stat-balance').textContent = gameData.balance + '€';
            document.getElementById('stat-location').textContent = gameData.airportName;
            document.getElementById('stat-penalties').textContent = gameData.penalties;
            route = gameData.route;
            flyIndex = 0;
            await loadAirportOptions();

            // piilota aloitusnäytön ja näyttää pelin
            document.getElementById('start-screen').classList.remove('active');
            document.getElementById('game-screen').classList.remove('hidden');
            document.getElementById('game-screen').classList.add('active');

        } catch (error) {
            console.error('Error:', error);
            alert('Error connecting to server! Make sure Flask is running.');
        }
    });

    // pelaaja painaa "go to work" nappia
    document.getElementById('btn-work').addEventListener('click', function () {
        // piilota päävalikon
        document.getElementById('main-menu').classList.add('hidden');
        // näytää työ screenin
        document.getElementById('work-screen').classList.remove('hidden');
        // näyttää työn ohjeet
        document.getElementById('work-intro').classList.remove('hidden');
        // piilottaa bag checkerin
        document.getElementById('bag-checker').classList.add('hidden');
        //piilota edllinen tulos
        document.getElementById('bag-result').classList.add('hidden');

        document.getElementById('work-message').textContent = getRandomWorkMessage();

        currentBagNumber = 0;
    });
    // menee takaiisn ohjeista
    document.getElementById('btn-back-from-work').addEventListener('click', function () {
        document.getElementById('work-screen').classList.add('hidden');
        document.getElementById('main-menu').classList.remove('hidden');
    });
    // pelaaja painaa "start checking bags"
    document.getElementById('btn-start-checking').addEventListener('click', async function () {
        // piilottaa työ ohjeet
        document.getElementById('work-intro').classList.add('hidden');

        // näyttää bag checker (varsinainen peli)
        document.getElementById('bag-checker').classList.remove('hidden');
        await loadNextBag();
    });
    // pelaaja painaa "fly to next destination"
    document.getElementById('btn-fly').addEventListener('click', function () {
        // piilottaa päävalikon
        document.getElementById('main-menu').classList.add('hidden');

        // näyttää fly screen
        document.getElementById('fly-screen').classList.remove('hidden');
    });

    // pelaaja painaa "go Bbck" nappia fly screenissä
    document.getElementById('btn-back-to-menu').addEventListener('click', function () {
        // piilottaa fly screenin
        document.getElementById('fly-screen').classList.add('hidden');

        // näyttää päävalikon
        document.getElementById('main-menu').classList.remove('hidden');
    });

    // pelaaja painaa "news" nappia
    document.getElementById('btn-news').addEventListener('click', function () {
        document.getElementById('main-menu').classList.add('hidden');
        document.getElementById('news-screen').classList.remove('hidden');
    });

    // pelaaja painaa "go Bbck" nappia news screenissä
    document.getElementById('btn-back-from-news').addEventListener('click', function () {
        document.getElementById('news-screen').classList.add('hidden');
        document.getElementById('main-menu').classList.remove('hidden');
    });

    let currentBagNumber = 0;
    let totalBags = 5;
    let isProcessing = false;

    //random workmessaget
    function getRandomWorkMessage() {
        const messages = [
            "Another shitty day ahead....",
            "It's a nice day to go to work. I need more money.",
            "A rainy day ahead. The bus is full of smelly people. How great...",
            "I'm tired. And the day just started.",
            "I'm late again. Hope nobody notices."
        ];
        return messages[Math.floor(Math.random() * messages.length)];
    }

    //seuraava laukku
    async function loadNextBag() {
        try {
            const response = await fetch('http://localhost:5420/api/work/get-bag');
            const data = await response.json();

            currentBagNumber = data.bagNumber;
            document.getElementById('bag-number').textContent = currentBagNumber;

            const itemsList = document.getElementById('bag-items-list');
            itemsList.innerHTML = '';

            data.items.forEach(item => {
                const li = document.createElement('li');
                li.textContent = item.description;
                itemsList.appendChild(li);
            });

            document.getElementById('bag-checker').classList.remove('hidden');
            document.getElementById('bag-result').classList.add('hidden');

        } catch (error) {
            console.error('Error loading bag: ', error);
            alert('Error loading bag!');
        }
    }

    //allow nappula
    document.getElementById('btn-allow').addEventListener('click', function() {
        if (!isProcessing) {  
            isProcessing = true;
            makeDecision('allow');
        }
    });

    //deny nappula
    document.getElementById('btn-deny').addEventListener('click', function() {
        if (!isProcessing) {  
            isProcessing = true;
            makeDecision('deny');
        }
    });

    //tarkistetaan päätös
    async function makeDecision(decision) {
        try {
            const response = await fetch('http://localhost:5420/api/work/check-decision', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({decision: decision})
            });

            const result = await response.json();

            document.getElementById('bag-checker').classList.add('hidden');
            document.getElementById('bag-result').classList.remove('hidden');

            const resultMessage = document.getElementById('result-message');
            
            let itemsHTML = `<p><strong>Items in bag:</strong></p><ul style="text-align: left;">`;
            result.itemNames.forEach(name => {
                itemsHTML += `<li>${name}</li>`;
            });
            itemsHTML += `</ul>`;

            // näytä syyt
            let reasonsHTML = '';
            if (result.reasons && result.reasons.length > 0) {
                reasonsHTML = `<p><strong>Reasons:</strong></p><ul>`;
                result.reasons.forEach(reason => {
                    reasonsHTML += `<li>${reason}</li>`;
                });
                reasonsHTML += `</ul>`;
            }

            if (result.gameOver) {
                showGameOver(result, itemsHTML, reasonsHTML);   

            } else if (result.correct) {
                resultMessage.innerHTML = `
                    <div class="result-correct">
                        <h3>Correct!</h3>
                        <p>${result.message}</p>
                        <p>+20€</p>
                        <p>New balance: ${result.newBalance}€</p>
                    </div>
                `;
            } else {
                resultMessage.innerHTML = `
                    <div class="result-wrong">
                        <h3>Wrong!</h3>
                        <p>${result.message}</p>
                        <p>-10€</p>
                        ${itemsHTML}
                        ${reasonsHTML}
                        <p>New balance: ${result.newBalance}€</p>
                        <p>Penalties: ${result.penalties}/5</p>
                    </div>
                `;
            }

            document.getElementById('stat-balance').textContent = result.newBalance + '€';
            document.getElementById('stat-penalties').textContent = result.penalties;

            if (!result.gameOver) {
                if (result.workDayFinished) {
                    document.getElementById('btn-next-bag').textContent = 'Finish work day';
                    document.getElementById('btn-next-bag').onclick = finishWorkDay;
                } else {
                    document.getElementById('btn-next-bag').textContent = 'Next bag';
                    document.getElementById('btn-next-bag').onclick = nextBag;
                }
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error checking decision!');
        }
        isProcessing = false;
    }

    function nextBag() {
        loadNextBag();
    }

    async function finishWorkDay() {
        try {
            const response = await fetch('http://localhost:5420/api/work/end-day', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'}
            });

            const result = await response.json();
            document.getElementById('stat-day').textContent = result.day;

            alert(`Work day completed! Day ${result.day}. Balance: ${result.balance}`);
            returnToMenu();
        } catch (error) {
            console.error('Error:', error);
        }
    }

    function returnToMenu() {
        document.getElementById('work-screen').classList.add('hidden');
        document.getElementById('main-menu').classList.remove('hidden');
    }

    function showGameOver(result, itemsHTML, reasonsHTML) {
        // Piilota kaikki muut ruudut
        document.getElementById('game-screen').classList.add('hidden');
        document.getElementById('work-screen').classList.add('hidden');
        
        // Näytä game over ruutu
        document.getElementById('game-over-screen').classList.remove('hidden');
        
        // Täytä game over syy
        document.getElementById('game-over-reason').innerHTML = `
            <h3>${result.message}</h3>
        `;
        
        // Täytä tilastot
        document.getElementById('final-player-name').textContent = document.getElementById('stat-name').textContent;
        document.getElementById('final-days').textContent = document.getElementById('stat-day').textContent;
        document.getElementById('final-balance').textContent = result.newBalance;
        document.getElementById('final-penalties').textContent = result.penalties;
        document.getElementById('final-bags-checked').textContent = result.bagsChecked;
        document.getElementById('final-location').textContent = document.getElementById('stat-location').textContent;
        
        // Näytä viimeisen laukun sisältö ja syyt
        document.getElementById('game-over-items').innerHTML = `
            <h3>Last Bag:</h3>
            ${itemsHTML}
            ${reasonsHTML}
        `;    
    }

    // restart game nappi
    document.getElementById('btn-restart-game').addEventListener('click', async function() {
        try {
            await fetch('http://localhost:5420/api/reset-game', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'}
            });
            // piilota game over
            document.getElementById('game-over-screen').classList.add('hidden');
            // näytä start screen
            document.getElementById('start-screen').classList.add('active');
            // tyhjennä lomake
            document.getElementById('player-name').value = '';
            document.getElementById('starting-country').value = 'Finland';
        } catch (error) {
            console.error('Error resetting game:', error);
            // Silti palaa aloitusruutuun
            document.getElementById('game-over-screen').classList.add('hidden');
            document.getElementById('start-screen').classList.add('active');
        }    
    });
    // quit game nappi
    const btnQuit = document.getElementById('btn-quit');
    if (btnQuit) {
        btnQuit.addEventListener('click', async function() {
            if (confirm('Are you sure you want to quit? Your progress will be lost.')) {
                try {
                    // Nollaa backend SESSION
                    await fetch('http://localhost:5420/api/reset-game', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'}
                    });
                    
                    // Palaa aloitusruutuun
                    document.getElementById('game-screen').classList.add('hidden');
                    document.getElementById('game-screen').classList.remove('active');
                    document.getElementById('start-screen').classList.add('active');
                    
                    // Tyhjennä lomake
                    document.getElementById('player-name').value = '';
                    document.getElementById('starting-country').value = 'Finland';
                    
                } catch (error) {
                    console.error('Error quitting game:', error);
                }
            }
        });
    }
});


//LENTÄMINEN

window.currentAirportChoices = null;

function clearAirportCards() {
    document.getElementById("airport-name-1").textContent = "-";
    document.getElementById("airport-distance-1").textContent = "Distance: -";
    document.getElementById("airport-price-1").textContent = "Cost: -";

    document.getElementById("airport-name-2").textContent = "-";
    document.getElementById("airport-distance-2").textContent = "Distance: -";
    document.getElementById("airport-price-2").textContent = "Cost: -";
}

function updateAirportCards(airports) {
    if (!airports || airports.length < 2) return;

    document.getElementById("airport-name-1").textContent =
        `${airports[0].name} (${airports[0].country})`;
    document.getElementById("airport-distance-1").textContent =
        `Distance: ${airports[0].distance} km`;
    document.getElementById("airport-price-1").textContent =
        `Cost: ${airports[0].price} €`;

    document.getElementById("airport-name-2").textContent =
        `${airports[1].name} (${airports[1].country})`;
    document.getElementById("airport-distance-2").textContent =
        `Distance: ${airports[1].distance} km`;
    document.getElementById("airport-price-2").textContent =
        `Cost: ${airports[1].price} €`;
}

async function loadAirportOptions() {
    if (!route) return;

    try {
        const response = await fetch("http://localhost:5420/api/fly-options", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ index: flyIndex, route: route })
        });

        const data = await response.json();

        if (data.error) {
            alert(data.error);
            return;
        }

        window.currentAirportChoices = data.airports;
        updateAirportCards(data.airports);

    } catch (err) {
        console.error(err);
        alert("Error loading airport options");
    }
}


async function chooseAirport(indexChoice) {
    if (!window.currentAirportChoices || window.currentAirportChoices.length < 2) {
        alert("Airport options not loaded yet!");
        return;
    }

    try {
        const response = await fetch("http://localhost:5420/api/fly", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                choice: indexChoice + 1,
                route: route,
                index: flyIndex,
                airportChoices: {
                    [route[flyIndex + 1]]: window.currentAirportChoices.map(a => [
                        a.name, a.country, a.lat, a.lon
                    ])
                }
            })
        });

        const data = await response.json();

        if (data.error) {
            alert(data.error);
            return;
        }


        document.getElementById('stat-location').textContent = data.player.location[0];
        document.getElementById('stat-balance').textContent = data.player.balance + "€";
        document.getElementById('stat-day').textContent = data.player.day;

        flyIndex = data.index;
        alert(data.message);

        if (data.arrived) {
            alert("🎉 You reached Australia!");
            document.getElementById('fly-screen').classList.add('hidden');
            document.getElementById('main-menu').classList.remove('hidden');
        } else {
            await loadAirportOptions(); // load next airports
        }

    } catch (err) {
        console.error(err);
        alert("Server error during flight.");
    }
}


document.addEventListener('DOMContentLoaded', function () {

    const btnFly = document.getElementById('btn-fly');
    if (btnFly) {
        btnFly.addEventListener('click', function () {
            document.getElementById('main-menu').classList.add('hidden');
            document.getElementById('fly-screen').classList.remove('hidden');

            clearAirportCards();
            if (window.currentAirportChoices) {
                updateAirportCards(window.currentAirportChoices);
            }
        });
    }


    const btnBackFly = document.getElementById('btn-back-to-menu');
    if (btnBackFly) {
        btnBackFly.addEventListener('click', function () {
            document.getElementById('fly-screen').classList.add('hidden');
            document.getElementById('main-menu').classList.remove('hidden');
        });
    }


    const btnAirport1 = document.getElementById('btn-airport-1');
    const btnAirport2 = document.getElementById('btn-airport-2');

    if (btnAirport1) btnAirport1.addEventListener('click', () => chooseAirport(0));
    if (btnAirport2) btnAirport2.addEventListener('click', () => chooseAirport(1));
});