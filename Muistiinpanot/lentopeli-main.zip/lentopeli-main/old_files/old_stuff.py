from flask import Flask, request, jsonify
from misc.runner import capture_output
from misc.misc import randomevent_boss1, randomevent_boss2, randomeve
app = Flask(__name__)

player =

@app.route("/boss1/start", methods=["GET"])
def boss1_start():
    text = capture_output(lambda: randomevent_boss1(player,choice=None))
    return  jsonify({"text": text, "awaiting_choice": True})

@app.route("/boss1/choose", methods=["POST"])
def boss1_choose():
    choice = request.json.get("choice")
    text = capture_output(lambda : randomevent_boss1(player, choice=choice))
    return jsonify({"text":text, "awaiting_choice":False})

##tänne items funktiot
from flask import Flask, jsonify,request
import items
import sys
sys.path.insert('../database/database.py')
import database

app = Flask(__name__)
connection = get_db("python","huihai")

SESSION = {
    "player": None,
    "current_bag": None,
    "round": 0,
    "total_rounds": 5,
    "conn": None,
    "round_history": [],
    "conn": None,
    "route": None,
    "current_index": 0,
    "airport_choices": {},
    "selected_airport": None,
}



@app.route("/new_bag", methods=["GET"])
def new_bag():
    if SESSION["player"] is None:
        return jsonify({"error": "Game not started"}), 400

    SESSION["round"] += 1
    bag = items.add_luggage(SESSION["conn"])
    SESSION["current_bag"] = bag

    return jsonify({
        "round": SESSION["round"],
        "total_rounds": SESSION["total_rounds"],
        "bag": bag
    })

import io
from contextlib import redirect_stdout

def capture_output(func):
    buf = io.StringIO()
    with redirect_stdout(buf):
        func()
    return buf.getvalue()

import io
from contextlib import redirect_stdout

def capture_output(func):
    buf = io.StringIO()
    with redirect_stdout(buf):
        func()
    return buf.getvalue()

from database import get_db, get_starting_airport, get_two_airports
from routes_config import ROUTES
import ui
from playerdata import create_player
import time

def main():

    while True:
        conn = get_db("python", "huihai")
        text = "Welcome to Show your Bag!\nScan, inspect, observer. Look for the things that don’t belong:\nsmuggled goods, restricted tech, banned items… or worse.\nOne mistake, and it’s not just your job on the line\n\n"
        for word in text:
            print(word, end="", flush=True)

            time.sleep(0.0001)
        player = create_player()

        print(f"\nHey! You’ve just received an invitation to your dream job in Australia! "
              f"\nThe problem is… you don’t have much money yet. Fortunately, you’re working as a luggage inspector at the airport. "
              f"\nBy taking new positions in airports a little closer to Australia, you can slowly make your way toward your final destination.\n")

        first_country = input("Enter the country that you want to start from (Finland, Sweden, Norway or Denmark):\n ").title()

        while first_country not in ROUTES:
                print("Invalid choice! You must choose Finland, Sweden, Norway or Denmark.")
                first_country = input("Enter the country that you want to start from:\n ").title()

        first_airport = get_starting_airport(conn, first_country)
        print(f"Your starting airport is: {first_airport[0]}, {first_airport[1]}")
        current_airport = first_airport

        player["location"] = current_airport

        route = ROUTES[first_country]
        current_index = 0

        # generates airports for the whole route
        airport_choices = {}
        for country in route:
            airports = get_two_airports(conn, country)
            if airports:
                airport_choices[country] = airports

        #sends airport_choices to ui.py
        result = ui.game_menu(player, conn, route, current_index, airport_choices)

        if result is False:  # if game ends
            print("\nGame over... Starting a new game...\n")
            continue  # start a new game


if __name__ == "__main__":
    main()

import io
from contextlib import redirect_stdout

def capture_output(func):
    buf = io.StringIO()
    with redirect_stdout(buf):
        func()
    return buf.getvalue()

import random
import news
from geopy.distance import geodesic
import items
from misc import trigger_random_event, randomevent_boss2, randomevent_boss1

#UI:PY ->
def fly_menu(player, conn, route, current_index, airport_choices):
    # Check if the player is already at the final destination
    if current_index >= len(route) - 1:
        print("\nYou are already at your final destination Australia!")
        return player["location"], current_index

    # Get the next country in the travel route
    next_country = route[current_index + 1]
    # Get the pre-saved airports for that country
    next_airports = airport_choices.get(next_country, [])

    # If no airports found, skip this country
    if not next_airports:
        print(f"\nNo valid airports found in {next_country}. Skipping this destination.")
        return player["location"], current_index + 1

    # Print the available airport options in the next country
    print(f"\nNext destination options in {next_country}: ")
    for i, airport in enumerate(next_airports, 1):
        distance, price = calculate_distance_and_price(player["location"], airport)
        print(f"{i}, {airport[0]} ({airport[1]}) - {distance} km, Price: {price} €")

    # Ask the player to choose an airport
    choice = input("Choose your next airport (1 or 2): ")
    if choice not in ["1", "2"]:
        print("Invalid choice, staying at current airport.")
        return player["location"], current_index

    # Select the chosen airport
    next_airport = next_airports[int(choice) - 1]
    distance, price = calculate_distance_and_price(player["location"], next_airport)

    # Check if player has enough money to fly
    if player["balance"] >= price:
        player["balance"] -= price
        player["location"] = next_airport
        player["day"] += 1
        current_index += 1
        balance = float(player['balance'])
        print(f"\nYou flew to: {next_airport[0]}, {next_airport[1]}")
        print(f"Flight cost: {price} €. Remaining balance: {balance:.2f} €")
        # Check if this is the final destination
        if current_index == len(route) - 1:
            balance = float(player['balance'])
            print("\nCongratulations! You have reached your final destination: Australia!")
            print(f"Days traveled: {player['day']}")
            print(f"Final balance: {balance:.2f} €")
            news.print_news_by_country("Australia")
            quit()
        # Return the new location and updated index
        return next_airport, current_index
    else:
        # Not enough money to fly
        print("\nNot enough money for this flight!")
        return player["location"], current_index

def work_message():
    # List of possible random work-related messages
    messages = [
        "\n\nAnother shitty day ahead...",
        "\n\nIt's a nice day to go to work. I need to earn more money.",
        "\n\nRainy day ahead. The bus is full of smelly people.\nHow great..",
        "\n\nStepped on dogshit when walking to work. I ***ing hate dogs",
        "\n\nWhy do I need to suffer like this. Waking up every morning for nothing\nWish I could get out of here",
        "\n\nIm so tired. And the day just started",
        "\n\nIm late again. Hope nobody notices",

    ]
    return random.choice(messages)

def work_day(player,connection):
    round_history = []
    player["balance_at_start"] = player["balance"]

    print(work_message())
    print("\n--- Work Day Begins ---")
    print("\nYou will see descriptions of five items inside luggage.\n"
          "Your task is to decide whether the bag is allowed or denied for the flight.\n"
          "A bag is denied if it contains one or more forbidden items.\n"
          "Dangerous items must never be allowed through, but small amounts of liquids "
          "and small sharp objects are acceptable.\n"
          "You will get a penalty if you answer wrong. After you get five penalties the game is over.\n"
          "Each day, you need to check a total of five bags.\n\n")

    base_salary = player["salary"]

    #checking for randomevents happening
    event=trigger_random_event(player)
    #if random event is a strike in the airport, workday ends
    if event == "randomevent1":
        return True

    total_rounds = 5
    for i in range(1, total_rounds + 1):  # 5 bags
        ongoing = items.play_round(i,total_rounds, player, round_history, connection)
        if not ongoing:  # game over inside play_round
            print("Game over! Thanks for playing")
            return False
    # If all 5 bags checked successfully:
    balance_change = player["balance"] - player["balance_at_start"]
    total_earnings = base_salary + balance_change

    player["balance"] += base_salary
    player["day"] += 1

    print(f"\nWork day complete! ")
    print(f"Base salary: {base_salary} € and performance result: {balance_change:.2f} €")
    print(f"Total earned today: {total_earnings:.2f} €")
    print(f"New balance: {player['balance']:.2f} €")
    print(f"Day {player['day']} begins.")

    if random.random() < 0.05:
        event = random.choice([randomevent_boss1, randomevent_boss2])
        event(player)

    input(f"\nPress Enter to return to main menu...")
    return True

def news_menu(player):
    # Show current news for the country where the player is located
    news.print_news_by_country(player["location"][1])
    input("Press enter to continue")

def quitgame_menu():
    # Print a goodbye message and quit the game
    print("\nThanks for playing!")
    quit()

def show_menu(player, conn, route, current_index, airport_choices):
    # Display the main player status menu
    print("\n" + "="*40)
    print(f"Alias: {player['name']}")
    print(f"Day {player['day']} ")
    print(f"Balance: {player['balance']:.2f} €")
    print(f"Location: {player['location'][0]}, {player['location'][1]}")
    print(f"Penalties: {player['penalties']} / 5")
    print("="*40)

    if current_index < len(route) - 1:
        next_country = route[current_index + 1]
        next_airports = airport_choices.get(next_country, [])

        if next_airports:
            print(f"\nNext destination options in {next_country}: ")
            for i, airport in enumerate(next_airports, 1):
                distance, price = calculate_distance_and_price(player["location"], airport)
                print(f"{i}, {airport[0]} ({airport[1]}) - {distance} km, Price: {price} €")
        else:
            print(f"\nNo valid airports found in {next_country}.")

    print("\nAvailable actions:")
    print("1. Go to work")
    print("2. Check current news")
    print("3. Fly to next destination")
    print("4. Quit game (game will not be saved)")

def game_menu(player, conn, route, current_index, airport_choices):
    # Main game loop
    while True:
        show_menu(player, conn, route, current_index, airport_choices)
        choice = input("Choose action: ")
        if choice == "1":
            result = work_day(player, conn)
            if not result:
                return False
        elif choice == "2":
            news_menu(player)
        elif choice == "3":
            player["location"], current_index = fly_menu(player, conn, route, current_index, airport_choices)
        elif choice == "4":
            quitgame_menu()
        else:
            print("Invalid choice.")


def play_round(round_number, total_rounds, player, round_history, connection):
    print(f"\n--- Bag {round_number} ---")
    bag = add_luggage(connection)
    show_bag(bag)
    allow = ask_decision()

    penalty_count = player.get("penalties", 0)
    game_over = False
    reasons = [] #kerätään syyt listaan

    #taso 5 esineet --> välitön game over
    danger_items = [item["name"] for item in bag if item["danger_level"] == 5]
    if allow and danger_items:
        reasons.append(f"Contained danger level 5 items: {', '.join(danger_items)}")
        print("\nGAME OVER: You allowed a bag that contained a danger level 5 item.")
        game_over = True

    # kielletyt esineet(ei taso 5)
    suspicious_items = [item["name"] for item in bag if item["security_class"] == 1 and item["danger_level"] < 5]
    if allow and suspicious_items and not game_over:
        reasons.append(f"Suspicious items allowed: {', '.join(suspicious_items)}")
        penalty_count += 1
        print("Warning! You let a suspicious item through the airport security! A penalty will be applied!")
        if penalty_count>=5:
            print("\nGAME OVER! You have received 5 penalties.\nYou are a threat to aviation")
            game_over = True



    # turvallisen laukun turha kieltäminen
    if not allow and is_safe_luggage(bag) and not game_over:
        reasons.append("Denied a completely safe bag")
        penalty_count += 1
        print("Why didnt you let that through a completely safe bag?")
        print("You have received a penalty")
        if penalty_count >= 5:
            print("\nGAME OVER! You have received 5 penalties.\nYou are a threat to aviation")
            game_over = True

    if not game_over:
        if reasons:  #päätös oli väärä
            player["balance"] -= 10
            print(f"Penalty: -10 €. New balance: {player['balance']:.2f} €")
        else:  #päätös oli oikein
            player["balance"] += 20
            print(f"Bonus: +20 €. New balance: {player['balance']:.2f} €")

    # oikein tarkastettu laukku
    if not reasons and not game_over:
        print("Correct! The bag was " + ("allowed" if allow else "denied") + ".")


    #laukun sisältö
    print("Items in the bag were:")
    for item in bag:
        print(" -", item["name"])

    #jos syitä on, tulostetaan ne
    if reasons:
        print("reason(s):")
        for r in reasons:
            print(" -", r)

    #päivitetään pelaajan tiedot ja historia
    round_info = {
        "round": round_number,
        "allowed": allow,
        "penalty_count": penalty_count,
        "bag": bag,
    }
    round_history.append(round_info)
    player["penalties"]=penalty_count

    if game_over:
        return False

    if round_number < total_rounds:
        input("\nPress Enter to continue to the next bag...")
    else:
        input("\nPress Enter to end your work day... ")
    return True


def show_bag(bag):
    text = "Scanning luggage..\nThe bag contains:\n"
    for char in text:
        print(char,end="", flush = True)
        time.sleep(0.09)
    for thing in bag:
        print(f" - {thing['description']}")

def ask_decision():
    while True:
        choice = input("\nDo you let the bag through security? [allow/deny]: ").strip().lower()
        if choice in ("allow", "a", "yes", "y"):
            return True
        if choice in ("deny", "d", "no", "n"):
            return False
        print("Please type 'allow' or 'deny'.")