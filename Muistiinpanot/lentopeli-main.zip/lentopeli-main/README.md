# lentopeli

## How to start

### Backend
```bash
cd back_end
python -m venv env
./env/scripts/activate # something like this on windows
source ./env/bin/activate  # on mac
python app.py
````

### Frontend
```bash
cd front_end
python3 -m http.server 8005
```